#include <iostream>
#include <vector>
#include <cmath>
#include <gflags/gflags.h>
#include <sys/time.h>
#include <fstream>
#include <iomanip> 

#include "graph.h"
#include "methods.h"
using namespace std;
using namespace Eigen;

DEFINE_string(file_name, "", "file name");
DEFINE_int32(num_trials, 1000, "number of trials");
DEFINE_int32(N, 1e4, "N");
DEFINE_double(rmax, 1e-4, "rmax");
DEFINE_string(method, "exact", "method");
DEFINE_string(pairs, "vertex-pairs", "pairs");
DEFINE_string(filename, "", "filename");
DEFINE_string(landmark, "degree", "landmark");

double get_current_time_sec()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

vector<int> generate_node(int n, int num)
{
  srandom(0);
  vector<int> node;
  for(int i=0; i<num; i++) {
    int v = random() % n;
    node.push_back(v);
  }
  return node;
}

vector<pair<int, int>> generate_vertex_pairs(int n, int num)
{
  srandom(0);
  vector<pair<int, int>> res;
  for (int i = 0; i < num; ++i)
  {
    int s = random() % n;
    int t = random() % n;
    res.push_back(make_pair(s, t));
  }
  return res;
}

vector<pair<int, int>> generate_edges(graph_t &G, int num)
{
  srandom(0);
  vector<pair<int, int>> res;
  int n = G.size();
  vector<int> sum(n + 1);
  for (int i = 1; i <= n; ++i)
  {
    sum[i] = sum[i - 1] + G[i - 1].size();
  }

  for (int i = 0; i < num; ++i)
  {
    int j = random() % sum[n];
    int v = upper_bound(sum.begin(), sum.end(), j) - sum.begin() - 1;
    res.push_back(make_pair(v, G[v][j - sum[v]]));
  }
  return res;
}

int main(int argc, char *argv[])
{
  gflags::SetUsageMessage("This is a program to test gflags");
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  graph_t G;
  // read_graph(FLAGS_file_name, G);
  int landmark;
  landmark = read_graph_degree(FLAGS_file_name, G);
  if(FLAGS_landmark == "degree") {
    cout << "landmark: " << FLAGS_landmark << endl;
  } else if(FLAGS_landmark == "core") {
    landmark = core_landmark(G);
    cout << "landmark: " << FLAGS_landmark << endl;
    // return 0;
  } else if(FLAGS_landmark == "pagerank") {
    landmark = pagerank_landmark(G);
    cout << "landmark: " << FLAGS_landmark << endl;
    // return 0;
  } else if(FLAGS_landmark == "ecc") {
    landmark = ecc_landmark(G, landmark);
    cout << "landmark: " << FLAGS_landmark << endl;
  } else if(FLAGS_landmark == "random") {
    cout << "landmark: " << FLAGS_landmark << endl;
    landmark = 0;
  }
  int n = G.size();
  cout << "cout # of vertices: " << n << endl;
  cerr << "# of vertices: " << n << endl;

  vector<int> bfs_parent;
  vector<int> bfs_order;
  compute_BFS_tree(G, bfs_parent, bfs_order, landmark);

  vector<pair<int, int>> pairs;
  vector<int> node;
  if (FLAGS_pairs == "vertex-pairs")
  {
    pairs = generate_vertex_pairs(n, FLAGS_num_trials);
  }
  else if (FLAGS_pairs == "edges")
  {
    pairs = generate_edges(G, FLAGS_num_trials);
  }
  else if (FLAGS_pairs == "node")
  {
    node = generate_node(n, FLAGS_num_trials);
    ifstream infile("query/" + FLAGS_filename + "-node.query");
    if(infile.good()) {
      cerr << "query file already generated!" << endl;
    } else {
      ofstream fout("query/" + FLAGS_filename + "-node.query");
      for(int i=0; i<FLAGS_num_trials; i++) {
        fout << node[i] << "\n";
      }
      fout.close();
    }
    infile.close();
  }

  if(FLAGS_pairs == "vertex-pairs") {
    ifstream infile("query/" + FLAGS_filename + "-pair.query");
    if(infile.good()) {
      cerr << "pair query file already generated!" << endl;
    } else {
      ofstream fout("query/" + FLAGS_filename + "-pair.query");
      for(int i=0; i<pairs.size(); i++) {
        int s = pairs[i].first, t = pairs[i].second;
        fout << s << " " << t << "\n";
      }
      fout.close();
    }
    infile.close();
  }

  if(FLAGS_method == "source_landmark") {
    int s = landmark;
    cout << "landmark node: " << landmark << endl;
    vector<double> gt;
    vector<double> lewalk;
    vector<double> spanningtree;
    ifstream infile("result/" + FLAGS_filename + "/baseline/" + to_string(landmark) + ".txt");
    if(infile.good()) {
      for(int i=0; i<n; i++) {
        double result;
        infile >> result;
        gt.push_back(result);
      }
    } else {
      gt = single_source_loop_erased_walk_baseline(G, s, landmark, 100000, FLAGS_filename);
    }
    infile.close();

    double max_error = 0.;
    double l1_error = 0.;
    double time = 0.;
    double start_time = get_current_time_sec();
    lewalk = single_source_loop_erased_walk(G, s, landmark, FLAGS_N, FLAGS_filename);
    double end_time = get_current_time_sec();
    time = end_time - start_time;
    for(int i=0; i<n; i++) {
      l1_error += abs(lewalk[i] - gt[i]);
      if(abs(lewalk[i] - gt[i]) > max_error) max_error = abs(lewalk[i] - gt[i]);
    }
    cout << "loop erased walk " << "N: " << FLAGS_N << endl;
    cout << "max error: " << max_error << endl;
    cout << "l1 error: " << l1_error << endl;
    cout << "time: " << time << endl;
    return 0;
  } else if(FLAGS_method == "source") {
    ofstream fout_lewalk("result/" + FLAGS_filename + "-lewalk-single-source-result.txt");
    ofstream fout_spanning_tree("result/" + FLAGS_filename + "-spanning-tree-single-source-result.txt");
    ofstream fout_pushp("result/" + FLAGS_filename + "-pushp-single-source-result.txt");
    ofstream fout_abwalkp("result/" + FLAGS_filename + "-abwalkp-single-source-result.txt");
    ifstream infile("query/" + FLAGS_filename + "-node.query");
    double avg_loop_erased_walk_time, avg_loop_erased_walk_max, avg_loop_erased_walk_l1 = 0.;
    double avg_spanning_tree_time, avg_spanning_tree_max, avg_spanning_tree_l1 = 0.;
    double avg_push_index_time, avg_push_index_max, avg_push_index_l1 = 0.;
    double avg_abwalk_index_time, avg_abwalk_index_max, avg_abwalk_index_l1 = 0.;
    double avg_monte_carlo_time, avg_monte_carlo_max, avg_monte_carlo_l1 = 0.;
    for(int i=0; i<FLAGS_num_trials; i++) {
      int s;
      for(int j=0; j<6; j++) infile >> s;

      // ground-truth
      vector<double> landmark_index_base;
      // load index
      ifstream infile2("result/" + FLAGS_filename + "/baseline/" + to_string(landmark) + ".txt");
      for(int i=0; i<n; i++) {
        double result;
        infile2 >> result;
        landmark_index_base.push_back(result);
      }
      vector<double> gt;
      ifstream infile1("result/" + FLAGS_filename + "/baseline/" + to_string(s) + ".txt");
      if(infile1.good()) {
        cerr << "ground-truth has been generated!" << endl;
        for(int i=0; i<n; i++) {
          double result;
          infile1 >> result;
          gt.push_back(result);
        }
      } else {
        cout << "ground truth: " << to_string(s) << endl;
        gt = single_source_push_index(G, s, landmark, 1e-6, FLAGS_filename, landmark_index_base);
      }
      infile1.close();

      // online method
      // query n Monte Carlo
      vector<double> monte_carlo;
      double max_error = 0.;
      double l1_error = 0.;
      double time = 0.;
      double start_time = get_current_time_sec();
      monte_carlo = single_source_monte_carlo(G, s, landmark, 10000, FLAGS_filename);
      double end_time = get_current_time_sec();
      time = end_time - start_time;
      for(int i=0; i<n; i++) {
        l1_error += abs(monte_carlo[i] - gt[i]);
        if(abs(monte_carlo[i] - gt[i]) > max_error) max_error = abs(monte_carlo[i] - gt[i]);
      }
      cout << "n monte carlo" << " N: " << endl;
      cout << "max error: " << max_error << endl;
      cout << "l1 error: " << l1_error << endl;
      cout << "time: " << time << endl;
      avg_monte_carlo_time += time;
      avg_monte_carlo_max += max_error;
      avg_monte_carlo_l1 += l1_error;

      // loop erased walk
      vector<double> lewalk;
      vector<double> spanningtree;
      l1_error = 0., max_error = 0.;
      start_time = get_current_time_sec();
      lewalk = single_source_loop_erased_walk(G, s, landmark, FLAGS_N, FLAGS_filename);
      end_time = get_current_time_sec();
      time = end_time - start_time;
      for(int i=0; i<n; i++) {
        l1_error += abs(lewalk[i] - gt[i]);
        if(abs(lewalk[i] - gt[i]) > max_error) max_error = abs(lewalk[i] - gt[i]);
      }
      cout << "loop erased walk" << " N: " << endl;
      cout << "max error: " << max_error << endl;
      cout << "l1 error: " << l1_error << endl;
      cout << "time: " << time << endl;
      avg_loop_erased_walk_time += time;
      avg_loop_erased_walk_max += max_error;
      avg_loop_erased_walk_l1 += l1_error;
      fout_lewalk << l1_error << " " << time << endl;

      // spanning tree
      vector<int> bfs_parent_s;
      vector<int> bfs_order_s;
      compute_BFS_tree(G, bfs_parent_s, bfs_order_s, s);

      l1_error = 0., max_error = 0.;
      start_time = get_current_time_sec();
      spanningtree = single_source_spanning_tree(G, s, landmark, FLAGS_N, FLAGS_filename, bfs_parent_s);
      end_time = get_current_time_sec();
      time = end_time - start_time;
      for(int i=0; i<n; i++) {
        l1_error += abs(spanningtree[i] - gt[i]);
        if(abs(spanningtree[i] - gt[i]) > max_error) max_error = abs(spanningtree[i] - gt[i]);
      }
      cout << "spanning tree " << "N: " << FLAGS_N << endl;
      cout << "max error: " << max_error << endl;
      cout << "l1 error: " << l1_error << endl;
      cout << "time: " << time << endl;
      avg_spanning_tree_time += time;
      avg_spanning_tree_max += max_error;
      avg_spanning_tree_l1 += l1_error;
      fout_spanning_tree << l1_error << " " << time << endl;

      // index based method

      vector<double> push_index;
      vector<double> abwalk_index;

      vector<double> landmark_index;
      // load index
      ifstream infile3("result/" + FLAGS_filename + "/looperasedwalk/" + to_string(landmark) + ".txt");
      for(int i=0; i<n; i++) {
        double result;
        infile3 >> result;
        landmark_index.push_back(result);
      }

      l1_error = 0., max_error = 0.;
      start_time = get_current_time_sec();
      push_index = single_source_push_index(G, s, landmark, FLAGS_rmax, FLAGS_filename, landmark_index);
      end_time = get_current_time_sec();
      time = end_time - start_time;
      for(int i=0; i<n; i++) {
        l1_error += abs(push_index[i] - gt[i]);
        if(abs(push_index[i] - gt[i]) > max_error) max_error = abs(push_index[i] - gt[i]);
      }
      cout << "push index" << " rmax: " << FLAGS_rmax << endl;
      cout << "max error: " << max_error << endl;
      cout << "l1 error: " << l1_error << endl;
      cout << "time: " << time << endl;
      avg_push_index_time += time;
      avg_push_index_max += max_error;
      avg_push_index_l1 += l1_error;
      fout_pushp << l1_error << " " << time << endl;

      l1_error = 0., max_error = 0.;
      start_time = get_current_time_sec();
      abwalk_index = single_source_abwalk_index(G, s, landmark, FLAGS_N, FLAGS_filename, landmark_index);
      end_time = get_current_time_sec();
      time = end_time - start_time;
      for(int i=0; i<n; i++) {
        l1_error += abs(abwalk_index[i] - gt[i]);
        if(abs(abwalk_index[i] - gt[i]) > max_error) max_error = abs(abwalk_index[i] - gt[i]);
      }
      cout << "abwalk index" << " N: " << FLAGS_N << endl;
      cout << "max error: " << max_error << endl;
      cout << "l1 error: " << l1_error << endl;
      cout << "time: " << time << endl;
      avg_abwalk_index_time += time;
      avg_abwalk_index_max += max_error;
      avg_abwalk_index_l1 += l1_error;
      fout_abwalkp << l1_error << " " << time << endl;
    }

    cout << "------------------avg_performance----------------------" << endl;
    cout << "N: " << FLAGS_N << endl;
    cout << "rmax: " << FLAGS_rmax << endl;
    cout << "Monte Carlo" << endl;
    cout << "avg time: " << avg_monte_carlo_time / FLAGS_num_trials << endl;
    cout << "avg max error: " << avg_monte_carlo_max / FLAGS_num_trials << endl;
    cout << "avg l1 error: " << avg_monte_carlo_l1 / FLAGS_num_trials << endl;

    cout << "loop erased walk" << endl;
    cout << "avg time: " << avg_loop_erased_walk_time / FLAGS_num_trials << endl;
    cout << "avg max error: " << avg_loop_erased_walk_max / FLAGS_num_trials << endl;
    cout << "avg l1 error: " << avg_loop_erased_walk_l1 / FLAGS_num_trials << endl;

    cout << "spanning tree" << endl;
    cout << "avg time: " << avg_spanning_tree_time / FLAGS_num_trials << endl;
    cout << "avg max error: " << avg_spanning_tree_max / FLAGS_num_trials << endl;
    cout << "avg l1 error: " << avg_spanning_tree_l1 / FLAGS_num_trials << endl;

    cout << "push index" << endl;
    cout << "avg time: " << avg_push_index_time / FLAGS_num_trials << endl;
    cout << "avg max error: " << avg_push_index_max / FLAGS_num_trials << endl;
    cout << "avg l1 error: " << avg_push_index_l1 / FLAGS_num_trials << endl;

    cout << "abwalk index" << endl;
    cout << "avg time: " << avg_abwalk_index_time / FLAGS_num_trials << endl;
    cout << "avg max error: " << avg_abwalk_index_max / FLAGS_num_trials << endl;
    cout << "avg l1 error: " << avg_abwalk_index_l1 / FLAGS_num_trials << endl;

    fout_lewalk.close();
    fout_abwalkp.close();
    fout_spanning_tree.close();
    fout_pushp.close();

    return 0;
  } else if(FLAGS_method == "monte-carlo") {
    ofstream fout_mc("result/" + FLAGS_filename + "-mc-single-source-result.txt");
    ifstream infile("query/" + FLAGS_filename + "-node.query");
    double avg_monte_carlo_time, avg_monte_carlo_max, avg_monte_carlo_l1 = 0.;
    for(int i=0; i<FLAGS_num_trials; i++) {
      int s;
      infile >> s;

      vector<double> landmark_index_base;
      // load index
      ifstream infile2("result/" + FLAGS_filename + "/baseline/" + to_string(landmark) + ".txt");
      for(int i=0; i<n; i++) {
        double result;
        infile2 >> result;
        landmark_index_base.push_back(result);
      }

      vector<double> gt;
      ifstream infile1("result/" + FLAGS_filename + "/baseline/" + to_string(s) + ".txt");
      if(infile1.good()) {
        cerr << "ground-truth has been generated!" << endl;
        for(int i=0; i<n; i++) {
          double result;
          infile1 >> result;
          gt.push_back(result);
        }
      } else {
        cout << "ground truth: " << to_string(s) << endl;
        gt = single_source_push_index(G, s, landmark, 1e-7, FLAGS_filename, landmark_index_base);
      }
      infile1.close();

      vector<double> monte_carlo;
      double max_error = 0.;
      double l1_error = 0.;
      double time = 0.;
      l1_error = 0., max_error = 0.;
      double start_time = get_current_time_sec();
      monte_carlo = single_source_monte_carlo_new(G, s, landmark, 10000, FLAGS_filename);
      double end_time = get_current_time_sec();
      time = end_time - start_time;
      for(int i=0; i<n; i++) {
        l1_error += abs(monte_carlo[i] - gt[i]);
        if(abs(monte_carlo[i] - gt[i]) > max_error) max_error = abs(monte_carlo[i] - gt[i]);
      }
      cout << "monte carlo" << " rmax: " << FLAGS_rmax << endl;
      cout << "max error: " << max_error << endl;
      cout << "l1 error: " << l1_error << endl;
      cout << "time: " << time << endl;
      avg_monte_carlo_time += time;
      avg_monte_carlo_max += max_error;
      avg_monte_carlo_l1 += l1_error;
      fout_mc << l1_error << " " << time << endl;
    }
    cout << "Monte Carlo" << endl;
    cout << "avg time: " << avg_monte_carlo_time / FLAGS_num_trials << endl;
    cout << "avg max error: " << avg_monte_carlo_max / FLAGS_num_trials << endl;
    cout << "avg l1 error: " << avg_monte_carlo_l1 / FLAGS_num_trials << endl;
    fout_mc.close();
    return 0;
  }

  double* gt = new double[FLAGS_num_trials]();
  ifstream gt_in("result/" + FLAGS_filename + "/gt/single-pair-result.txt");
  if(gt_in.good()) {
    cerr << "ground-truth has been generated!" << endl;
    for(int i=0; i<FLAGS_num_trials; i++) {
      gt_in >> gt[i];
    }
  } else {
    ifstream infile1("query/" + FLAGS_filename + "-pair.query");
    ofstream fout1("result/" + FLAGS_filename + "/gt/single-pair-result.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile1 >> s >> t;
      cerr << s << " " << t << endl;
      double start_time = get_current_time_sec();
      double result = effective_resistance_bipush(G, s, t, landmark, 1e-5, 10000);
      double end_time = get_current_time_sec();
      fout1 << setprecision(16) << result << endl;
    }
    infile1.close();
    fout1.close();
  }
  gt_in.close();

  double max_error = 0.;
  double avg_error = 0.;

  double avg_time = 0.;

  max_error = 0.;
  avg_error = 0.;
  avg_time = 0.;

  if(FLAGS_method == "akp") {
    ifstream infile3("query/" + FLAGS_filename + "-pair.query");
    ofstream fout3("result/" + FLAGS_filename + "-akp-single-pair-result.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile3 >> s >> t;
      double start_time = get_current_time_sec();
      double result = effective_resistance_akp(G, s, t, 100, 10000);
      double end_time = get_current_time_sec();
      fout3 << setprecision(16) << abs(result-gt[i]) << " " << end_time-start_time << endl;
      if(abs(result-gt[i])>max_error) max_error = abs(result-gt[i]);
      avg_error += abs(result-gt[i]);
      avg_time += end_time-start_time;
    }
    infile3.close();
    cout << "akp" << endl;
    cout << "max error: " << max_error << endl;
    cout << "avg error: " << avg_error / FLAGS_num_trials << endl;
    cout << "avg time: " << avg_time / FLAGS_num_trials << endl;
  } else if(FLAGS_method == "commute") {
    ifstream infile3("query/" + FLAGS_filename + "-pair.query");
    ofstream fout3("result/" + FLAGS_filename + "-commute-single-pair-result.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile3 >> s >> t;
      double start_time = get_current_time_sec();
      double result = effective_resistance_mc(G, s, t, 0.1, 0.1);
      double end_time = get_current_time_sec();
      fout3 << setprecision(16) << abs(result-gt[i]) << " " << end_time-start_time << endl;
      if(abs(result-gt[i])>max_error) max_error = abs(result-gt[i]);
      avg_error += abs(result-gt[i]);
      avg_time += end_time-start_time;
    }
    infile3.close();
    cout << "commute" << endl;
    cout << "max error: " << max_error << endl;
    cout << "avg error: " << avg_error / FLAGS_num_trials << endl;
    cout << "avg time: " << avg_time / FLAGS_num_trials << endl;
  } else if(FLAGS_method == "abwalk") {
    ifstream infile3("query/" + FLAGS_filename + "-pair.query");
    ofstream fout3("result/" + FLAGS_filename + "-abwalk-single-pair-result.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile3 >> s >> t;
      double start_time = get_current_time_sec();
      double result = effective_resistance_mc3(G, s, t, landmark, FLAGS_N);
      double end_time = get_current_time_sec();
      fout3 << setprecision(16) << abs(result-gt[i]) << " " << end_time-start_time << endl;
      if(abs(result-gt[i])>max_error) max_error = abs(result-gt[i]);
      avg_error += abs(result-gt[i]);
      avg_time += end_time-start_time;
    }
    infile3.close();
    cout << "abwalk" << " N: " << FLAGS_N << endl;
    cout << "max error: " << max_error << endl;
    cout << "avg error: " << avg_error / FLAGS_num_trials << endl;
    cout << "avg time: " << avg_time / FLAGS_num_trials << endl;
  } else if(FLAGS_method == "localtree") {
    ifstream infile3("query/" + FLAGS_filename + "-pair.query");
    ofstream fout3("result/" + FLAGS_filename + "-localtree-single-pair-result.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile3 >> s >> t;
      double start_time = get_current_time_sec();
      double result = effective_resistance_local_tree(G, s, t, landmark, FLAGS_N, bfs_parent);
      double end_time = get_current_time_sec();
      fout3 << setprecision(16) << abs(result-gt[i]) << " " << end_time-start_time << endl;
      if(abs(result-gt[i])>max_error) max_error = abs(result-gt[i]);
      avg_error += abs(result-gt[i]);
      avg_time += end_time-start_time;
    }
    infile3.close();
    cout << "localtree" << " N: " << FLAGS_N << endl;
    cout << "max error: " << max_error << endl;
    cout << "avg error: " << avg_error / FLAGS_num_trials << endl;
    cout << "avg time: " << avg_time / FLAGS_num_trials << endl;
  } else if(FLAGS_method == "bipush") {
    ifstream infile3("query/" + FLAGS_filename + "-pair.query");
    ofstream fout3("result/" + FLAGS_filename + "-bipush-single-pair-result.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile3 >> s >> t;
      double start_time = get_current_time_sec();
      double result = effective_resistance_bipush(G, s, t, landmark, FLAGS_rmax, FLAGS_N);
      double end_time = get_current_time_sec();
      fout3 << setprecision(16) << abs(result-gt[i]) << " " << end_time-start_time << endl;
      if(abs(result-gt[i])>max_error) max_error = abs(result-gt[i]);
      avg_error += abs(result-gt[i]);
      avg_time += end_time-start_time;
    }
    infile3.close();
    cout << "bipush" << " N: " << FLAGS_N << " rmax: " << FLAGS_rmax << endl;
    cout << "max error: " << max_error << endl;
    cout << "avg error: " << avg_error / FLAGS_num_trials << endl;
    cout << "avg time: " << avg_time / FLAGS_num_trials << endl;
  } else if(FLAGS_method == "push") {
    ifstream infile3("query/" + FLAGS_filename + "-pair.query");
    ofstream fout3("result/" + FLAGS_filename + "-push-single-pair-result-4.txt");
    for(int i=0; i<pairs.size(); i++) {
      int s, t;
      infile3 >> s >> t;
      double start_time = get_current_time_sec();
      double result = effective_resistance_push(G, s, t, landmark, FLAGS_rmax);
      double end_time = get_current_time_sec();
      fout3 << setprecision(16) << abs(result-gt[i]) << " " << end_time-start_time << endl;
      if(abs(result-gt[i])>max_error) max_error = abs(result-gt[i]);
      avg_error += abs(result-gt[i]);
      avg_time += end_time-start_time;
    }
    infile3.close();
    cout << "push" << " rmax: " << FLAGS_rmax << endl;
    cout << "max error: " << max_error << endl;
    cout << "avg error: " << avg_error / FLAGS_num_trials << endl;
    cout << "avg time: " << avg_time / FLAGS_num_trials << endl;
  }

  return 0;
}