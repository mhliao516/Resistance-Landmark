This is the source code for the paper “Efficient Resistance Distance Computation: the Power of Landmark-based Approaches”. To reproduce the results, run:

sh facebook.sh

sh facebook-parameter.sh

sh facebook-landmark.sh