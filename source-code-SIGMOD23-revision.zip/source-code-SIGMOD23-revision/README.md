This is the source code for the submitted paper. To reproduce the results, run:

sh facebook.sh

sh facebook-parameter.sh

sh facebook-landmark.sh

Other datasets (small graphs) are also provided in graphs/ directory.

Large graphs are available at http://konect.cc/networks/